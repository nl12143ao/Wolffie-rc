// modules/solaredge-modbus/services/collector.js
import db from '../../../core/database.js';
import api from './api.js';
import { localTimestamp } from '../../../core/utils/localTimestamp.js';

class SolarEdgeCollector {
  constructor() {
    this.config             = null;
    this.lastData           = null;
    this.lastCollectionTime = null;
    this.lastError          = null;
    this.consecutiveErrors  = 0;
  }

  // ── Daily baseline ─────────────────────────────────────────────────────────

  async _readDailyBaseline() {
    try {
      const [rows] = await db.pool.query(
        `SELECT setting_key, setting_value
           FROM system_settings
          WHERE category = 'solaredge-modbus'
            AND setting_key IN ('daily_baseline_date', 'daily_baseline_pv_total')`
      );
      if (!rows.length) return null;
      const m     = Object.fromEntries(rows.map(r => [r.setting_key, r.setting_value]));
      const today = new Date();
      const p     = n => String(n).padStart(2, '0');
      const dateStr = `${today.getFullYear()}-${p(today.getMonth()+1)}-${p(today.getDate())}`;
      if (m.daily_baseline_date !== dateStr) return null;
      return parseFloat(m.daily_baseline_pv_total ?? 0);
    } catch (err) {
      console.warn('[SolarEdge] Could not read daily baseline:', err.message);
      return null;
    }
  }

  async _writeDailyBaseline(pvTotalWh) {
    const today      = new Date();
    const p          = n => String(n).padStart(2, '0');
    const dateStr    = `${today.getFullYear()}-${p(today.getMonth()+1)}-${p(today.getDate())}`;
    const pvTotalKwh = pvTotalWh / 1000;

    const entries = [
      ['daily_baseline_date',     dateStr,                'string'],
      ['daily_baseline_pv_total', pvTotalKwh.toFixed(4),  'number'],
    ];

    try {
      for (const [key, value, type] of entries) {
        await db.pool.query(
          `INSERT INTO system_settings
             (category, setting_key, setting_value, value_type, description)
           VALUES ('solaredge-modbus', ?, ?, ?, ?)
           ON CONFLICT(category, setting_key) DO UPDATE SET
             setting_value = excluded.setting_value,
             updated_at    = datetime('now')`,
          [key, value, type, `SolarEdge daily baseline — ${key}`]
        );
      }
    } catch (err) {
      console.warn('[SolarEdge] baseline write failed (will retry next cycle):', err.message);
    }
  }

  // ── Collect ────────────────────────────────────────────────────────────────

  async collect() {
    if (!this.config?.host) return true;
    if (this.config.enabled === false || this.config.enabled === 'false') return true;

    try {
      await api.connect(this.config);
      const data = await api.fetchAll();
      await api.disconnect();

      let solarEnergyToday = 0;
      if (data.energy_total !== null) {
        const pvTotalWh  = data.energy_total;
        const pvTotalKwh = pvTotalWh / 1000;
        let baselineKwh  = await this._readDailyBaseline();
        if (baselineKwh === null) {
          await this._writeDailyBaseline(pvTotalWh);
          baselineKwh = pvTotalKwh;
        }
        solarEnergyToday = Math.max(0, Math.round((pvTotalKwh - baselineKwh) * 100) / 100);
      }

      this.lastData = { ...data, solar_energy_today: solarEnergyToday };
      await this.storeSnapshot(data, solarEnergyToday);

      this.lastCollectionTime = new Date();
      this.lastError          = null;
      this.consecutiveErrors  = 0;

      const solarW  = Math.max(0, Math.round(data.power_ac ?? 0));
      const tempStr = (data.temp_sink !== null && data.temp_sink > -200 && data.temp_sink < 200)
        ? `${data.temp_sink.toFixed(1)}°C` : 'n/a';
      const voltStr = (data.voltage_ln !== null && data.voltage_ln > 0 && data.voltage_ln < 300)
        ? `${data.voltage_ln.toFixed(1)}V` : 'n/a';

      console.log(
        `   • SolarEdge ModBus – ${new Date().toLocaleString()}` +
        `  Solar=${solarW}W  Today=${solarEnergyToday}kWh` +
        `  Temp=${tempStr}  Voltage=${voltStr}`
      );

      return true;

    } catch (error) {
      this.lastError = error.message;
      this.consecutiveErrors++;
      await api.disconnect();
      console.error(`\x1b[31m   • SolarEdge Collector Error: ${error.message}\x1b[37m`);
      return false;
    }
  }

  // ── Store ──────────────────────────────────────────────────────────────────

  async storeSnapshot(data, solarEnergyToday) {
    const solarPower = Math.max(0, Math.round(data.power_ac ?? 0));
    const gridVoltL1 = (data.voltage_ln !== null && data.voltage_ln > 80 && data.voltage_ln < 300)
      ? data.voltage_ln : null;
    const invTemp    = (data.temp_sink !== null && data.temp_sink > -200 && data.temp_sink < 200)
      ? data.temp_sink : null;

    await db.pool.query(
      `INSERT INTO energy_snapshots (
        timestamp, source, device_id,
        solar_power, solar_energy_today,
        battery_power, battery_soc, battery_voltage, battery_current, battery_temp,
        grid_power, grid_voltage_l1, grid_voltage_l2, grid_voltage_l3,
        grid_current_l1, grid_current_l2, grid_current_l3, grid_frequency,
        grid_energy_import_today, grid_energy_export_today,
        load_power, load_energy_today, inverter_temp, inverter_power,
        battery_charge_today, battery_discharge_today,
        trees_equivalent, co2_offset_kg
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        localTimestamp(),
        'solaredge-modbus',
        'solaredge-se',
        solarPower,       solarEnergyToday,
        null, null, null, null, null,
        null, gridVoltL1,
        null, null, null, null, null, null,
        null, null, null, null,
        invTemp, solarPower,
        null, null,
        0.0, 0.0,
      ]
    );
  }

  getStatus() {
    return {
      lastCollection:    this.lastCollectionTime,
      lastError:         this.lastError,
      consecutiveErrors: this.consecutiveErrors,
      lastData:          this.lastData,
    };
  }
}

export default new SolarEdgeCollector();