// modules/my-module/routes/index.js
// Express router — mounted at the prefix defined in manifest.json (e.g. /api/my-module).
// Only import api.js and collector.js here. Never talk to the DB directly.

import express from 'express';
import api       from '../services/api.js';
import collector from '../services/collector.js';

const router = express.Router();

// ── GET /api/my-module/status ──────────────────────────────────────────────
// Returns the latest collected snapshot — used by the dashboard.
router.get('/status', async (req, res) => {
  try {
    const latest = await collector.getLatest();
    if (!latest) return res.status(404).json({ error: 'No data collected yet' });
    res.json(latest);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/my-module/test ────────────────────────────────────────────────
// Quickly verify that the device/API is reachable.
// Useful as a "Test connection" button in the settings UI.
router.get('/test', async (req, res) => {
  try {
    const data = await api.fetchData();
    res.json({ success: true, data });
  } catch (err) {
    res.status(503).json({ success: false, error: err.message });
  }
});

// ── POST /api/my-module/command ────────────────────────────────────────────
// Send a command to the device. Body: { command: string, params?: object }
router.post('/command', async (req, res) => {
  const { command, params } = req.body;
  if (!command) return res.status(400).json({ error: 'command is required' });

  try {
    const result = await api.sendCommand(command, params);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
