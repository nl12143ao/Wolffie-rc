// modules/my-module/services/collector.js
// Runs on every poll interval (set in manifest.json → collector.interval).
// Responsibility: call api.js to get data, then write it to the database.
// Never import axios or talk to the outside world here — use api.js for that.

import api from './api.js';
import db  from '../../../core/database.js';

class MyModuleCollector {
  constructor() {
    this.config = null;
  }

  // ── Main collection cycle ──────────────────────────────────────────────
  // Called by collectorManager on each tick.
  // Must return { success: true/false } so collectorManager can track health.
  async collect(config) {
    this.config = config;

    try {
      // 1. Fetch raw data from the device / API
      const raw = await api.fetchData();

      // 2. Transform / validate
      const snapshot = this.transform(raw);

      // 3. Persist to DB
      await this.store(snapshot);

      return { success: true, data: snapshot };
    } catch (err) {
      console.error('[my-module collector] collect() failed:', err.message);
      return { success: false, error: err.message };
    }
  }

  // ── Transform raw API response → DB-ready object ───────────────────────
  transform(raw) {
    return {
      // TODO: map your raw API fields to meaningful names
      value1:    typeof raw.value1 === 'number' ? raw.value1 : null,
      value2:    typeof raw.value2 === 'number' ? raw.value2 : null,
      collected_at: raw.timestamp ?? new Date().toISOString(),
    };
  }

  // ── Persist snapshot ───────────────────────────────────────────────────
  async store(snapshot) {
    // TODO: replace table name and columns with your own schema
    await db.pool.query(`
      INSERT INTO my_module_snapshots
        (value1, value2, collected_at)
      VALUES
        (?, ?, ?)
      ON DUPLICATE KEY UPDATE
        value1       = VALUES(value1),
        value2       = VALUES(value2),
        collected_at = VALUES(collected_at)
    `, [
      snapshot.value1,
      snapshot.value2,
      snapshot.collected_at,
    ]);
  }

  // ── Latest snapshot (used by routes) ──────────────────────────────────
  async getLatest() {
    const [rows] = await db.pool.query(`
      SELECT * FROM my_module_snapshots
      ORDER BY collected_at DESC
      LIMIT 1
    `);
    return rows[0] ?? null;
  }
}

export default new MyModuleCollector();
