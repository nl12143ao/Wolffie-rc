// modules/my-module/services/api.js
// Handles ALL communication with the external device or API.
// collector.js and routes/index.js call functions from here — never talk
// to the outside world directly from those files.

class MyModuleApi {
  constructor() {
    this.config = null;
    this.client = null;   // e.g. an axios instance, a TCP socket, etc.
  }

  // ── Initialise connection ──────────────────────────────────────────────
  async initialize(config) {
    this.config = config;

    // TODO: set up your HTTP client, WebSocket, serial port, etc.
    // Example (HTTP):
    //   const axios = (await import('axios')).default;
    //   this.client = axios.create({ baseURL: `http://${config.host}:${config.port}` });
    //
    // Example (TCP / Modbus):
    //   const ModbusRTU = (await import('modbus-serial')).default;
    //   this.client = new ModbusRTU();
    //   await this.client.connectTCP(config.host, { port: config.port });
  }

  // ── Fetch latest data ──────────────────────────────────────────────────
  // Called by collector.js on every poll interval.
  // Should return a plain object with the raw values you want to store.
  async fetchData() {
    if (!this.client) throw new Error('Client not initialised — call initialize() first');

    // TODO: replace with your actual API call
    // const response = await this.client.get('/api/v1/data');
    // return response.data;

    return {
      value1: Math.random() * 100,
      value2: Math.random() * 50,
      timestamp: new Date().toISOString(),
    };
  }

  // ── Optional: send a command ───────────────────────────────────────────
  // Called from routes/index.js when the frontend triggers an action.
  async sendCommand(command, params = {}) {
    if (!this.client) throw new Error('Client not initialised');

    // TODO: implement write / command logic
    console.log(`[my-module] sendCommand: ${command}`, params);
    return { success: true };
  }

  // ── Teardown ───────────────────────────────────────────────────────────
  async disconnect() {
    // TODO: close open connections gracefully
    this.client = null;
  }
}

export default new MyModuleApi();
