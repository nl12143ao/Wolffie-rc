# my-module — Wolffie Module Skeleton

Copy this folder, rename it, and fill in the TODOs to create a new Wolffie module.

## File structure

```
my-module/
├── manifest.json              # Module descriptor — read by moduleLoader on startup
├── index.js                   # Entry point — lifecycle, collector wiring, router wiring
├── config/
│   └── settings_schema.json   # Dynamic settings UI schema (universalSettingsPanel)
├── locales/
│   ├── en.json                # English translations
│   └── nl.json                # Dutch translations (add de.json, fr.json as needed)
├── routes/
│   └── index.js               # Express router, mounted at manifest → routes.prefix
└── services/
    ├── api.js                 # ALL external communication lives here
    └── collector.js           # Poll logic + DB persistence
```

## Quick start

### 1. Rename

Replace every occurrence of `my-module` / `MyModule` / `myModule` with your module ID / name.

```bash
# Files to update:
# - manifest.json         → change id, name, prefix, etc.
# - index.js              → log label
# - services/api.js       → class name, log prefix
# - services/collector.js → class name, log prefix, DB table
# - routes/index.js       → route paths
# - config/settings_schema.json → i18n keys, field keys
# - locales/*.json        → translation keys + values
```

### 2. Implement api.js

`api.js` is the only file that talks to the outside world.

```js
// HTTP example
import axios from 'axios';
this.client = axios.create({ baseURL: `http://${config.host}:${config.port}` });
const response = await this.client.get('/data');

// Modbus TCP example
import ModbusRTU from 'modbus-serial';
this.client = new ModbusRTU();
await this.client.connectTCP(config.host, { port: config.port ?? 502 });
```

### 3. Implement collector.js

- `transform(raw)` — map raw API response to DB columns
- `store(snapshot)` — write to your DB table (create the table in a migration first)
- `getLatest()` — return the most recent row (called by routes)

### 4. Add DB table

Create a migration file or run manually:

```sql
CREATE TABLE IF NOT EXISTS my_module_snapshots (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  value1       DECIMAL(10,2),
  value2       DECIMAL(10,2),
  collected_at DATETIME NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_collected_at (collected_at)
);
```

### 5. Update settings_schema.json

The schema drives the settings UI automatically via `universalSettingsPanel`.
Field components available: `text`, `number`, `switch`, `select`, `password`, `textarea`.

### 6. Install

Zip the module folder and upload via Settings → Install/Update modules,
or drop the folder directly into `modules/` and restart the server.

## Architecture rules

| File | Allowed imports | NOT allowed |
|---|---|---|
| `api.js` | axios, modbus-serial, any device SDK | db, collector |
| `collector.js` | `api.js`, `db` | axios, device SDKs |
| `routes/index.js` | `api.js`, `collector.js` | db directly |
| `index.js` | `api.js`, `collector.js`, `routes/index.js` | db directly |

## Settings schema field reference

```json
{
  "key":         "field_key",          // maps to DB setting key
  "component":  "text|number|switch|select|password",
  "label":      "i18n.key.or.plain",
  "placeholder":"i18n.key.or.plain",
  "description":"i18n.key.or.plain",
  "required":    true,
  "cols":        6,                    // 1–12 grid columns (12 = full width)
  "min":         0,                    // number only
  "max":         100,                  // number only
  "suffix":      "ms",                 // number only
  "options": [                         // select only
    { "value": "a", "label": "i18n.key" }
  ]
}
```
