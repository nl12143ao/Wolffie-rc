// modules/my-module/index.js
// Entry point — moduleLoader imports this file and calls initialize()

import collector from './services/collector.js';
import api      from './services/api.js';

const module = {
  // ── Lifecycle ──────────────────────────────────────────────────────────
  // Called by moduleLoader after the module is enabled.
  // Use this to open connections, validate config, etc.
  async initialize() {
    await api.initialize(this.config);
    console.log(`   ✓ my-module initialized`);
  },

  // ── Collector ──────────────────────────────────────────────────────────
  // collectorManager calls collect() on the interval defined in manifest.json
  async collect() {
    return collector.collect(this.config);
  },

  // ── Routes ─────────────────────────────────────────────────────────────
  // routeManager calls getRouter() and mounts it at routes.prefix
  getRouter() {
    const { default: router } = await import('./routes/index.js');
    return router;
  },

  // ── Config ─────────────────────────────────────────────────────────────
  // Populated by moduleLoader from settingsService before initialize() is called.
  // Access settings in any service via:  this.config.host, this.config.port, etc.
  config: {},

  // Called by collectorManager/settingsService when settings change at runtime
  async reinitialize(newConfig) {
    this.config = newConfig;
    await this.initialize();
  },
};

export default module;
