// modules/alphaess-modbus-tcp/services/collector.js
import db from '../../../core/database.js';
import api from './api.js';
import { localTimestamp } from '../../../core/utils/localTimestamp.js';

class AlphaModbusCollector {
  constructor() {
    this.lastCollectionTime = null;
    this.lastError          = null;
    this.consecutiveErrors  = 0;
    this.config             = null;
  }

  async collect() {
    try {
      return await this._doCollect();
    } catch (e) {
      console.error(`\x1b[31m   • AlphaESS ModBus Collector [outer guard]: ${e.message}\x1b[37m`);
      this.lastError = e.message;
      this.consecutiveErrors++;
      try { await api.client.close(); } catch (_) {}
      api.isConnected = false;
      return false;
    }
  }

  async _doCollect() {
    if (!this.config?.host) {
      console.warn(`   • AlphaESS ModBus: no config available yet, skipping`);
      return true;
    }

    try {
      try { await api.client.close(); } catch (_) {}
      api.isConnected = false;
      await api.connect(this.config.host, this.config.port, this.config.unit_id);
    } catch (connErr) {
      console.error(`\x1b[31m   • AlphaESS ModBus Collector Error: ${connErr.message}\x1b[37m`);
      this.lastError = connErr.message;
      this.consecutiveErrors++;
      try { await api.client.close(); } catch (_) {}
      api.isConnected = false;
      return false;
    }

    let m;
    try {
      m = await api.fetchAll();
    } catch (fetchErr) {
      console.error(`\x1b[31m   • AlphaESS ModBus Collector Error: ${fetchErr.message}\x1b[37m`);
      this.lastError = fetchErr.message;
      this.consecutiveErrors++;
      try { await api.client.close(); } catch (_) {}
      api.isConnected = false;
      return false;
    }

    const gridPowerSource = this.config?.grid_power_source ?? 'internal';
    let gridPowerDB = null;

    if (gridPowerSource === 'internal') {
      gridPowerDB = m.grid.total_active_power * -1;
    } else if (gridPowerSource === 'homewizard-p1') {
      try {
        const [p1Rows] = await db.pool.query(
          `SELECT grid_power FROM energy_snapshots
           WHERE source = 'homewizard-p1'
           ORDER BY timestamp DESC LIMIT 1`
        );
        gridPowerDB = (p1Rows.length > 0 && p1Rows[0].grid_power !== null)
          ? p1Rows[0].grid_power
          : m.grid.total_active_power * -1;
      } catch (err) {
        gridPowerDB = m.grid.total_active_power * -1;
      }
    }

    const loadPower = Math.max(0,
      m.solar.total_power + m.battery.power + gridPowerDB
    );
    const loadEnergyToday = m.home?.energy_today ?? Math.max(0,
      m.solar.energy_today +
      (m.grid.import_today - m.grid.export_today) +
      (m.battery.discharge_today - m.battery.charge_today)
    );

    await this.storeSnapshot(m, gridPowerDB, loadPower, loadEnergyToday);

    this.lastCollectionTime = new Date();
    this.lastError          = null;
    this.consecutiveErrors  = 0;
    console.log(`   • AlphaESS ModBus - ${new Date().toLocaleString()} SOC=${Math.round(m.battery.soc)}%  Solar=${m.solar.total_power}W  Grid=${gridPowerDB}W  Load=${Math.round(loadPower)}W`);
    return true;
  }

  async storeSnapshot(m, gridPowerDB, loadPower, loadEnergyToday) {
    await db.pool.query(
      `INSERT INTO energy_snapshots (
        timestamp, source, device_id,
        solar_power, solar_energy_today,
        battery_power, battery_soc, battery_voltage, battery_current, battery_temp,
        grid_power, grid_voltage_l1, grid_voltage_l2, grid_voltage_l3,
        grid_current_l1, grid_current_l2, grid_current_l3, grid_frequency,
        grid_energy_import_today, grid_energy_export_today,
        load_power, load_energy_today, inverter_temp, inverter_power,
        battery_charge_today, battery_discharge_today,
        trees_equivalent, co2_offset_kg
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        localTimestamp(),
        'alphaess-modbus-tcp',
        'alpha-smile-g3-t10',
        null, null,
        m.battery.power,
        Math.round(m.battery.soc),
        null, null, null,
        gridPowerDB,
        m.grid.l1_voltage,
        null, null, null, null, null,
        m.system.inv_freq ?? 50.0,
        m.grid.import_today,
        m.grid.export_today,
        Math.round(loadPower),
        loadEnergyToday,
        m.system.inverter_temp,
        m.solar.total_power,
        m.battery.charge_today,
        m.battery.discharge_today,
        0.0, 0.0,
      ]
    );
  }

  getStatus() {
    return {
      lastCollection:    this.lastCollectionTime,
      lastError:         this.lastError,
      consecutiveErrors: this.consecutiveErrors,
    };
  }
}

export default new AlphaModbusCollector();