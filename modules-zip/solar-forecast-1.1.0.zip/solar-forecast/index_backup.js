// modules/solar-forecast/index.js
import { readFileSync, existsSync } from 'fs';
import { fileURLToPath, pathToFileURL } from 'url';
import { dirname, join } from 'path';
import db from '../../core/database.js';
import collector from './services/collector.js';
import settingsService from '../../core/system/services/settingsService.js';
import capabilityRegistry from '../../core/capabilityRegistry.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

const manifest = JSON.parse(readFileSync(join(__dirname, 'manifest.json'), 'utf-8'));

const MODULE_ID = 'solar-forecast';
const PRIORITY  = 10;

class SolarForecastModule {
  constructor() {
    this.manifest    = manifest;
    this.collector   = collector;
    this.initialized = false;
    this.config      = null;
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  async initialize() {
    if (this.initialized) return;

    try {
      console.log(`   - \x1b[93m${MODULE_ID} \x1b[37m`);
      this.config = await settingsService.getCategory(MODULE_ID);

      if (!this.config || this.config.enabled === false) {
        console.log(`     - ${MODULE_ID}: disabled in settings`);
        return;
      }

      if (!this.config.latitude || !this.config.longitude) {
        console.warn(`     - ${MODULE_ID}: missing latitude/longitude — solar:forecast not registered`);
        return;
      }

      if (!this.config.kwp) {
        console.warn(`     - ${MODULE_ID}: missing panel power (kWp) — solar:forecast not registered`);
        return;
      }

      console.log(`     - Location: ${this.config.latitude}°, ${this.config.longitude}°`);
      console.log(`     - Panel power: ${this.config.kwp} kWp`);
      console.log(`     - Tilt: ${this.config.tilt ?? 'N/A'}°, Azimuth: ${this.config.azimuth ?? 'N/A'}°`);

      // Pre-load routes
      this.routes = await this._loadRoutes();

      this._registerCapabilities();

      this.initialized = true;
      console.log(`     - Capabilities registered \x1b[32m✓\x1b[37m`);

    } catch (error) {
      console.error(`\x1b[91m     - ${MODULE_ID}: initialize failed:`, error.message, '\x1b[37m');
      throw error;
    }
  }

  async collect() {
    return await this.collector.collect();
  }

  getStatus() {
    const cs = typeof this.collector.getStatus === 'function'
      ? this.collector.getStatus() : {};
    return {
      initialized:  this.initialized,
      enabled:      this.config?.enabled ?? false,
      hasConfig:    !!this.config,
      latitude:     this.config?.latitude,
      longitude:    this.config?.longitude,
      panelPower:   this.config?.kwp,
      tilt:         this.config?.tilt,
      azimuth:      this.config?.azimuth,
      collector: {
        lastRun:   cs.lastRun   ?? null,
        lastError: cs.lastError ?? null,
        healthy:   cs.healthy   !== false,
      },
    };
  }

  getRoutes() {
    return this.routes ?? null;
  }

  async _loadRoutes() {
    try {
      const routesPath = join(__dirname, 'routes', 'index.js');
      if (existsSync(routesPath)) {
        const m = await import(pathToFileURL(routesPath).href);
        return m.default;
      }
    } catch (e) {
      console.warn(`     - ${MODULE_ID}: route loading failed:`, e.message);
    }
    return null;
  }

  async reinitialize() {
    console.log(`   - ♻️  ${MODULE_ID}: reinitializing with fresh settings`);
    this.config = await settingsService.getCategory(MODULE_ID);
    collector.config = this.config;

    if (this.config?.latitude && this.config?.longitude && this.config?.kwp) {
      this._registerCapabilities();
    } else {
      capabilityRegistry.unregister(MODULE_ID);
    }
  }

  // ── Capability Registration ────────────────────────────────────────────────

  _registerCapabilities() {
    capabilityRegistry.register(
      'solar:forecast',
      async (body = {}) => {
        const windowHours = body.windowHours ?? 24;
        const windowStart = body.windowStart ?? new Date();
        const windowEnd   = new Date(windowStart);
        windowEnd.setHours(windowEnd.getHours() + windowHours);

        // Collect dates covered by the window
        const dates = [];
        const d = new Date(windowStart);
        d.setHours(0, 0, 0, 0);
        while (d <= windowEnd) {
          dates.push(d.toISOString().split('T')[0]);
          d.setDate(d.getDate() + 1);
        }

        // Fetch hourly forecast slots for all dates in window
        const placeholders = dates.map(() => '?').join(',');
        const [rows] = await db.pool.query(`
          SELECT slot_datetime, hourly_wh, date
          FROM solar_forecast_hourly
          WHERE date IN (${placeholders})
          ORDER BY slot_datetime ASC
        `, dates);

        // Normalise — include datetime for rolling window indexing
        const hourly = rows.map(row => ({
          datetime: new Date(row.slot_datetime).toISOString(),
          hour:     new Date(row.slot_datetime).getHours(),
          date:     row.date,
          watts:    Math.round(parseFloat(row.hourly_wh) || 0),
        }));

        // Total forecast kWh across the window
        const totalWh  = hourly.reduce((sum, s) => sum + s.watts, 0);
        const totalKwh = Math.round(totalWh / 100) / 10;

        // Daily summaries for accuracy factor
        const [summaryRows] = await db.pool.query(
          `SELECT date, expected_kwh, actual_kwh, accuracy_percentage
           FROM solar_forecasts WHERE date IN (${placeholders})`,
          dates
        );

        return {
          hourly,
          totalKwh,
          dailySummaries: summaryRows,
          // Legacy: today's summary for backward compat
          expectedKwh:        parseFloat(summaryRows[0]?.expected_kwh)      || totalKwh,
          actualKwh:          parseFloat(summaryRows[0]?.actual_kwh)         ?? null,
          accuracyPercentage: parseFloat(summaryRows[0]?.accuracy_percentage) ?? null,
        };
      },
      PRIORITY,
      MODULE_ID
    );
  }
}

export default new SolarForecastModule();