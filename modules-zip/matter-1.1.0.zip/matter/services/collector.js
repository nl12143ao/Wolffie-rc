// modules/matter/services/collector.js
import db from '../../../core/database.js';
import matterAPI from './api.js';
import { localTimestamp } from '../../../core/utils/localTimestamp.js';

class MatterCollector {
  constructor() {
    this.devices = [];
    this.devicesLoaded = false;
    this.lastCollectionTime = null;
    this.lastError = null;
    this.consecutiveErrors = 0;
  }

  async loadDevices() {
    const [rows] = await db.pool.query(
      "SELECT * FROM device_settings WHERE module = 'matter' AND enabled = 1"
    );
    this.devices       = rows;
    this.devicesLoaded = true;
  }

  async collect() {
    try {
      if (!this.devicesLoaded) await this.loadDevices();
      if (this.devices.length === 0) return true;

      const results = await Promise.allSettled(
        this.devices.map(device => this.collectFromDevice(device))
      );

      this.lastCollectionTime = new Date();
      const failures          = results.filter(r => r.status === 'rejected');
      this.consecutiveErrors  = failures.length;

      if (failures.length > 0) {
        this.lastError = failures[0].reason?.message || 'Partial collection failure';
        return failures.length < this.devices.length;
      }

      this.lastError = null;
      return true;
    } catch (error) {
      this.lastError = error.message;
      return false;
    }
  }

  async collectFromDevice(device) {
    const data = await matterAPI.getDeviceAttributes(device.serial);
    await db.pool.query(
      `INSERT INTO device_measurements (
        timestamp, device_id, device_type, device_name, source,
        power, energy_total, extra_metrics
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        localTimestamp(),
        device.serial,
        device.product_type || 'matter-device',
        device.name,
        'matter',
        (data.activePower    / 1000) || 0,
        (data.cumulativeEnergy / 1000) || 0,
        JSON.stringify({
          voltage:        data.voltage / 1000,
          current:        data.current / 1000,
          matter_node_id: device.serial,
        }),
      ]
    );
  }

  getStatus() {
    return {
      deviceCount:       this.devices.length,
      lastCollection:    this.lastCollectionTime,
      lastError:         this.lastError,
      consecutiveErrors: this.consecutiveErrors,
    };
  }
}

export default new MatterCollector();